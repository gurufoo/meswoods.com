<div class="panel-display omega-grid omega-24-onecol" <?php if (!empty($css_id)) { print "id=\"$css_id\""; } ?>>
  <div class="panel-panel">
    <div class="inside"><?php print $content['middle']; ?></div>
  </div>
</div>
