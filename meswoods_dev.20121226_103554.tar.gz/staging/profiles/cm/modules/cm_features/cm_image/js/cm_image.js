(function ($) {

  $(function() {
    // Handler for .ready() called.
    $("a.image-gallery").colorbox({
      rel:'image-gallery',
      maxHeight:'100%',
      maxWidth:'100%',
    });
  });

})(jQuery);

