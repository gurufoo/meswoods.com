<?php
/**
 * MultiPoint: A collection Points  
 */
class MultiPoint extends Collection
{
  protected $geom_type = 'MultiPoint';
}

